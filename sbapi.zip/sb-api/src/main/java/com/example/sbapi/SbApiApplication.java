package com.example.sbapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbApiApplication.class, args);
	}

}
