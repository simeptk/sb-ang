package com.example.sbapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
